// Generado por C3DS - Whack_a_mole
// Compilar con devkitARM + libctru + citro2d (ver Makefile).
#include <3ds.h>
#include <citro2d.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#define NUM_OBJS 5
#define NUM_VARS 2
#define NUM_SCENES 2
#define NUM_SOUNDS 1
#define START_SCENE 0

enum { T_RECT, T_TEXT, T_SPRITE, T_BUTTON };

typedef struct {
	int type, scene, screen, image, controls, tmpl, anim_off, anim_n, anim_fps;
	float x, y, w, h, speed, vx, vy, gravity, tsize;
	int visible;
	u32 color;
	int solid, follow;
	float fspeed, opacity;
	int align, cols, rows, flip, fixed;
	float par;
} Obj;

static const Obj init_objs[5] = {
	{ 0, 0, 1, 0, 0, -1, 0, 0, 8, 140.0f, 100.0f, 44.0f, 44.0f, 3.0f, 0.000f, 0.000f, 0.000f, 1.000f, 1, 0xFF3652AB, 0, -1, 1.000f, 1.000f, 0, 1, 1, 0, 0, 1.000f }, // 20
	{ 1, 0, 0, 0, 0, 0, 0, 0, 8, 10.0f, 8.0f, 0.0f, 0.0f, 3.0f, 0.000f, 0.000f, 0.000f, 1.000f, 1, 0xFFFFFFFF, 0, -1, 1.000f, 1.000f, 0, 1, 1, 0, 0, 1.000f }, // 21
	{ 1, 0, 0, 0, 0, 1, 0, 0, 8, 90.0f, 110.0f, 0.0f, 0.0f, 3.0f, 0.000f, 0.000f, 0.000f, 1.000f, 1, 0xFFE8F1FF, 0, -1, 1.000f, 1.000f, 0, 1, 1, 0, 0, 1.000f }, // 22
	{ 1, 1, 0, 0, 0, 2, 0, 0, 8, 120.0f, 90.0f, 0.0f, 0.0f, 3.0f, 0.000f, 0.000f, 0.000f, 1.000f, 1, 0xFFFFFFFF, 0, -1, 1.000f, 1.000f, 0, 1, 1, 0, 0, 1.000f }, // 26
	{ 3, 1, 1, 0, 0, 3, 0, 0, 8, 100.0f, 100.0f, 120.0f, 40.0f, 3.0f, 0.000f, 0.000f, 0.000f, 1.000f, 1, 0xFFFFAD29, 0, -1, 1.000f, 1.000f, 0, 1, 1, 0, 0, 1.000f }, // 27
};
static Obj objs[5];
static int vars[NUM_VARS] = { 0, 20 };
static u32 keys_up = 0;
static int paused = 0; /* acción “Pausar”: congela movimiento y reglas que no sean de entrada */
#define FADE_ON 1
static int fade_frames = FADE_ON ? 18 : 0;
static int cur_scene = START_SCENE, next_scene = -1, scene_frames = 0, quit = 0;
static const u32 scene_bg[NUM_SCENES][2] = {
	{ 0xFF518700, 0xFF4F575F },
	{ 0xFF53257E, 0xFF532B1D },
};
static const float screen_w[2] = { 400.0f, 320.0f };
static const float scene_world[NUM_SCENES] = { 400.0f, 400.0f };
static const int scene_cam[NUM_SCENES] = { -1, -1 };
static float cam_x = 0;
static float cam_f(const Obj* o) { return o->fixed ? 0.0f : o->par; }
static float max_w(const Obj* o) { return (o->screen == 0 && cam_f(o) > 0.0f) ? scene_world[cur_scene] : screen_w[o->screen]; }
static void update_camera(void) {
	cam_x = 0;
	int c = scene_cam[cur_scene];
	if (c < 0) return;
	const Obj* t = &objs[c];
	cam_x = t->x + t->w / 2 - screen_w[0] / 2;
	if (cam_x > scene_world[cur_scene] - screen_w[0]) cam_x = scene_world[cur_scene] - screen_w[0];
	if (cam_x < 0) cam_x = 0;
}
static const float screen_h[2] = { 240.0f, 240.0f };

static void format_text(int tmpl, char* out, size_t n) {
	switch (tmpl) {
	case 0: snprintf(out, n, "Score: %d   Time: %d", vars[0], vars[1]); break;
	case 1: snprintf(out, n, "Tap the mole on the bottom screen"); break;
	case 2: snprintf(out, n, "Time\342\200\231s up! You whacked %d", vars[0]); break;
	case 3: snprintf(out, n, "Again"); break;
	default: out[0] = 0; break;
	}
}

static int hit(int a, int b) {
	const Obj *p = &objs[a], *q = &objs[b];
	return p->visible && q->visible && p->screen == q->screen &&
		p->x < q->x + q->w && q->x < p->x + p->w && p->y < q->y + q->h && q->y < p->y + p->h;
}

static int blocked(int i) {
	for (int j = 0; j < NUM_OBJS; j++)
		if (j != i && objs[j].solid && objs[j].scene == objs[i].scene && hit(i, j)) return j;
	return -1;
}

static int touch_in(int i, int touched, int tx, int ty) {
	const Obj* o = &objs[i];
	return touched && o->visible && o->screen == 1 && tx >= o->x && tx < o->x + o->w && ty >= o->y && ty < o->y + o->h;
}

static int standing_on(int i, int j) {
	const Obj *a = &objs[i], *b = &objs[j];
	return a->visible && b->visible && a->screen == b->screen && a->vy >= 0 &&
		a->y + a->h >= b->y - 1 && a->y + a->h <= b->y + 3 && a->x < b->x + b->w && b->x < a->x + a->w;
}

static void land_on(int i, int j) {
	objs[i].y = objs[j].y - objs[i].h;
	objs[i].vy = 0;
}

static int edge_hit(int i, int e) {
	const Obj* o = &objs[i];
	if (!o->visible) return 0;
	switch (e) {
	case 0: return o->x <= 0;
	case 1: return o->x + o->w >= max_w(o);
	case 2: return o->y <= 0;
	default: return o->y + o->h >= screen_h[o->screen];
	}
}

/* mode: 0 = X e Y, 1 = solo X, 2 = solo Y */
static void random_pos(int i, int mode) {
	Obj* o = &objs[i];
	float mw = max_w(o) - o->w, mh = screen_h[o->screen] - o->h;
	if (mode != 2) o->x = (float)(rand() % (int)(mw > 1 ? mw : 1));
	if (mode != 1) o->y = (float)(rand() % (int)(mh > 1 ? mh : 1));
}

/* ---------- Guardado (variables marcadas con "guardar") en la SD ---------- */
#define NUM_PERSIST 0
#if NUM_PERSIST > 0
static const int persist_idx[NUM_PERSIST] = {  };
static const char* save_dir = "sdmc:/3ds/whack-a-mole";
static const char* save_file = "sdmc:/3ds/whack-a-mole/save.dat";

static void load_vars(void) {
	FILE* f = fopen(save_file, "rb");
	if (!f) return;
	int tmp[NUM_PERSIST];
	if (fread(tmp, sizeof(int), NUM_PERSIST, f) == NUM_PERSIST) for (int i = 0; i < NUM_PERSIST; i++) vars[persist_idx[i]] = tmp[i];
	fclose(f);
}

static void save_vars(void) {
	mkdir("sdmc:/3ds", 0777);
	mkdir(save_dir, 0777);
	FILE* f = fopen(save_file, "wb");
	if (!f) return;
	int tmp[NUM_PERSIST];
	for (int i = 0; i < NUM_PERSIST; i++) tmp[i] = vars[persist_idx[i]];
	fwrite(tmp, sizeof(int), NUM_PERSIST, f);
	fclose(f);
}
#else
static void load_vars(void) {}
static void save_vars(void) {}
#endif

static void enter_scene(int s) {
	save_vars();
	cur_scene = s;
	scene_frames = 0;
	paused = 0;
	fade_frames = FADE_ON ? 18 : 0;
	for (int i = 0; i < NUM_OBJS; i++) if (init_objs[i].scene == s) objs[i] = init_objs[i];
}

/* ---------- Audio (ndsp, WAV PCM16 en romfs:/sounds) ---------- */
#if NUM_SOUNDS > 0
typedef struct { s16* data; u32 samples; u32 rate; int channels; int ok; } Sound;
static Sound sounds[NUM_SOUNDS];
static ndspWaveBuf wave_bufs[NUM_SOUNDS];
static int audio_ok = 0;
static const char* sound_files[NUM_SOUNDS] = {
	"romfs:/sounds/hit-17.wav",
};
static const int sound_loop[NUM_SOUNDS] = { 0 };
static const float sound_vol[NUM_SOUNDS] = { 1.000f };

static void load_sounds(void) {
	audio_ok = R_SUCCEEDED(ndspInit());
	if (!audio_ok) return;
	ndspSetOutputMode(NDSP_OUTPUT_STEREO);
	for (int i = 0; i < NUM_SOUNDS; i++) {
		FILE* f = fopen(sound_files[i], "rb");
		if (!f) continue;
		u8 h[44];
		if (fread(h, 1, 44, f) != 44 || memcmp(h, "RIFF", 4) || memcmp(h + 36, "data", 4)) { fclose(f); continue; }
		u32 size = h[40] | (h[41] << 8) | (h[42] << 16) | ((u32)h[43] << 24);
		sounds[i].channels = h[22];
		sounds[i].rate = h[24] | (h[25] << 8) | (h[26] << 16) | ((u32)h[27] << 24);
		sounds[i].data = (s16*)linearAlloc(size);
		if (sounds[i].data && fread(sounds[i].data, 1, size, f) == size) {
			DSP_FlushDataCache(sounds[i].data, size);
			sounds[i].samples = size / (2 * sounds[i].channels);
			sounds[i].ok = 1;
		}
		fclose(f);
	}
}

static void play_sound(int i) {
	if (!audio_ok || i < 0 || i >= NUM_SOUNDS || !sounds[i].ok) return;
	float mix[12] = { 0 };
	mix[0] = mix[1] = sound_vol[i];
	ndspChnReset(i);
	ndspChnSetInterp(i, NDSP_INTERP_LINEAR);
	ndspChnSetRate(i, (float)sounds[i].rate);
	ndspChnSetFormat(i, sounds[i].channels == 1 ? NDSP_FORMAT_MONO_PCM16 : NDSP_FORMAT_STEREO_PCM16);
	ndspChnSetMix(i, mix);
	memset(&wave_bufs[i], 0, sizeof(ndspWaveBuf));
	wave_bufs[i].data_vaddr = sounds[i].data;
	wave_bufs[i].nsamples = sounds[i].samples;
	wave_bufs[i].looping = sound_loop[i] ? true : false;
	ndspChnWaveBufAdd(i, &wave_bufs[i]);
}

static void stop_sound(int i) {
	if (!audio_ok || i < 0 || i >= NUM_SOUNDS) return;
	ndspChnReset(i);
}

static void free_sounds(void) {
	if (!audio_ok) return;
	for (int i = 0; i < NUM_SOUNDS; i++) if (sounds[i].data) linearFree(sounds[i].data);
	ndspExit();
}
#else
static void load_sounds(void) {}
static void play_sound(int i) { (void)i; }
static void stop_sound(int i) { (void)i; }
static void free_sounds(void) {}
#endif

/* ---------- Lógica ---------- */
static void update(u32 down, u32 held, int touched, int tx, int ty, float cx, float cy) {
	if (!paused) for (int i = 0; i < NUM_OBJS; i++) {
		Obj* o = &objs[i];
		if (o->scene != cur_scene || !o->visible) continue;
		float ox = o->x, oy = o->y;
		/* controls: 0 ninguno, 1 D-Pad, 2 horizontal, 3 vertical, 4 Circle Pad, 5 stylus */
		if (o->controls == 4) { o->x += cx * o->speed; o->y += cy * o->speed; }
		if (o->controls == 5 && (held & KEY_TOUCH) && o->screen == 1) { o->x = tx - o->w / 2; o->y = ty - o->h / 2; }
		if (o->controls >= 1 && o->controls <= 3 && o->controls != 3) {
			if (held & KEY_DLEFT)  o->x -= o->speed;
			if (held & KEY_DRIGHT) o->x += o->speed;
		}
		if (o->controls >= 1 && o->controls <= 3 && o->controls != 2) {
			if (held & KEY_DUP)    o->y -= o->speed;
			if (held & KEY_DDOWN)  o->y += o->speed;
		}
		if (o->follow >= 0) {
			const Obj* t = &objs[o->follow];
			if (t->visible && t->screen == o->screen && t->scene == o->scene) {
				float fdx = (t->x + t->w / 2) - (o->x + o->w / 2), fdy = (t->y + t->h / 2) - (o->y + o->h / 2);
				float fd = sqrtf(fdx * fdx + fdy * fdy);
				if (fd > 0.5f) { float fk = (o->fspeed < fd ? o->fspeed : fd) / fd; o->x += fdx * fk; o->y += fdy * fk; }
			}
		}
		if (o->gravity != 0) { o->vy += o->gravity; if (o->vy > 12) o->vy = 12; }
		o->x += o->vx;
		o->y += o->vy;
		float nx = o->x, ny = o->y;
		if (nx < 0) nx = 0;
		if (ny < 0) ny = 0;
		if (nx > max_w(o) - o->w) nx = max_w(o) - o->w;
		if (ny > screen_h[o->screen] - o->h) ny = screen_h[o->screen] - o->h;
		o->x = nx; o->y = oy;
		if (blocked(i) >= 0) o->x = ox;
		o->y = ny;
		{
			int w = blocked(i);
			if (w >= 0) {
				o->y = (ny > oy) ? objs[w].y - o->h : objs[w].y + objs[w].h;
				if (o->y < 0 || o->y > screen_h[o->screen] - o->h) o->y = oy;
				o->vy = 0;
			}
		}
	}
	(void)down; (void)held; (void)touched; (void)tx; (void)ty; (void)cx; (void)cy;
	switch (cur_scene) {
	case 0: // Game
		if (touch_in(0, touched, tx, ty)) {
			vars[0] += 1;
			play_sound(0);
			random_pos(0, 0);
		}
		if (!paused && (scene_frames > 0 && scene_frames % 60 == 0)) {
			vars[1] += -1;
			random_pos(0, 0);
		}
		if (!paused && vars[1] <= 0) {
			next_scene = 1;
		}
		break;
	case 1: // End
		if (touch_in(4, touched, tx, ty)) {
			vars[0] = 0;
			vars[1] = 20;
			next_scene = 0;
		}
		break;
	default: break;
	}
	update_camera();
	if (!paused) { scene_frames++; if (fade_frames > 0) fade_frames--; }
}

/* ---------- Dibujo ---------- */
static C2D_TextBuf text_buf;

static u32 with_alpha(u32 c, float a) {
	if (a >= 1.0f) return c;
	if (a < 0.0f) a = 0.0f;
	return (c & 0x00FFFFFFu) | ((u32)(a * 255.0f) << 24);
}

static void draw_text(const char* s, float x, float y, u32 color, float size, int center) {
	C2D_Text t;
	C2D_TextParse(&t, text_buf, s);
	C2D_TextOptimize(&t);
	C2D_DrawText(&t, C2D_WithColor | (center ? C2D_AlignCenter : 0), x, y, 0.0f, 0.55f * size, 0.55f * size, color);
}

static void draw_screen(int screen) {
	char buf[96];
	for (int i = 0; i < NUM_OBJS; i++) {
		const Obj* o = &objs[i];
		if (o->scene != cur_scene || !o->visible || o->screen != screen) continue;
		float ox = (screen == 0) ? o->x - cam_x * cam_f(o) : o->x;
		switch (o->type) {
		case T_RECT: C2D_DrawRectSolid(ox, o->y, 0.0f, o->w, o->h, with_alpha(o->color, o->opacity)); break;
		case T_SPRITE:
			C2D_DrawRectSolid(ox, o->y, 0.0f, o->w, o->h, with_alpha(o->color, o->opacity));
			break;
		case T_TEXT: format_text(o->tmpl, buf, sizeof buf); draw_text(buf, ox, o->y, with_alpha(o->color, o->opacity), o->tsize, o->align); break;
		case T_BUTTON:
			C2D_DrawRectSolid(ox, o->y, 0.0f, o->w, o->h, with_alpha(o->color, o->opacity));
			format_text(o->tmpl, buf, sizeof buf);
			draw_text(buf, ox + 6, o->y + o->h / 2 - 8 * o->tsize, with_alpha(0xFF000000, o->opacity), o->tsize, 0);
			break;
		}
	}
	if (fade_frames > 0) C2D_DrawRectSolid(0, 0, 0.0f, screen_w[screen], screen_h[screen], with_alpha(0xFF000000, fade_frames / 18.0f));
}

int main(int argc, char* argv[]) {
	(void)argc; (void)argv;
	gfxInitDefault();
	romfsInit();
	C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
	C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
	C2D_Prepare();
	C3D_RenderTarget* top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
	C3D_RenderTarget* bottom = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
	text_buf = C2D_TextBufNew(8192);
	load_sounds();
	srand((unsigned)svcGetSystemTick());
	load_vars();
	enter_scene(START_SCENE);

	while (aptMainLoop() && !quit) {
		hidScanInput();
		u32 down = hidKeysDown(), held = hidKeysHeld();
		keys_up = hidKeysUp();
		touchPosition tp;
		circlePosition cp;
		hidTouchRead(&tp);
		hidCircleRead(&cp);
		float cx = cp.dx / 156.0f, cy = -cp.dy / 156.0f;
		if (cx > -0.1f && cx < 0.1f) cx = 0;
		if (cy > -0.1f && cy < 0.1f) cy = 0;
		update(down, held, (down & KEY_TOUCH) != 0, tp.px, tp.py, cx, cy);
		if (next_scene >= 0) { enter_scene(next_scene); next_scene = -1; }

		C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
		C2D_TextBufClear(text_buf);
		C2D_TargetClear(top, scene_bg[cur_scene][0]);
		C2D_SceneBegin(top);
		draw_screen(0);
		C2D_TargetClear(bottom, scene_bg[cur_scene][1]);
		C2D_SceneBegin(bottom);
		draw_screen(1);
		C3D_FrameEnd(0);
	}

	save_vars();
	free_sounds();
	C2D_TextBufDelete(text_buf);
	C2D_Fini();
	C3D_Fini();
	romfsExit();
	gfxExit();
	return 0;
}
