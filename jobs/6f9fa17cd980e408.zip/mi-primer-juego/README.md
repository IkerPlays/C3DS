# Mi primer juego

Proyecto para Nintendo 3DS homebrew generado con C3DS.

## Compilar
1. Instala [devkitPro](https://devkitpro.org) con el grupo `3ds-dev` (devkitARM, libctru, citro2d, tex3ds).
2. `make` → `mi-primer-juego.3dsx` (cópialo a `/3ds/` en la SD y ábrelo desde Homebrew Launcher).
3. `make cia` → `mi-primer-juego.cia` (instálalo con FBI). Necesita [makerom](https://github.com/3DSGuy/Project_CTR) y [bannertool](https://github.com/diasurgical/bannertool) en el PATH.

También puedes subir esta carpeta a GitHub: el workflow incluido compila ambos archivos.

## Probar
Abre el `.3dsx` o el `.cia` en el emulador [Azahar](https://azahar-emu.org). El sonido necesita el firmware DSP (dump de tu consola) en consola real/emulador.

## Archivos
- `source/main.c`: juego (generado).
- `gfx/`: imágenes PNG y `sprites.t3s` (lista para tex3ds).
- `romfs/sounds/`: sonidos WAV.
- `cia/`: `app.rsf`, banner, icono y audio del banner (personalízalos).
