// Generado por C3DS - Mi primer juego
// Compilar con devkitARM + libctru + citro2d (ver Makefile).
#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUM_OBJS 6
#define NUM_VARS 1
#define NUM_SCENES 2
#define NUM_SOUNDS 2
#define START_SCENE 0

enum { T_RECT, T_TEXT, T_SPRITE, T_BUTTON };

typedef struct {
	int type, scene, screen, image, controls, tmpl;
	float x, y, w, h, speed;
	int visible;
	u32 color;
} Obj;

static const Obj init_objs[6] = {
	{ 1, 0, 0, 0, 0, 0, 230.0f, 175.0f, 0.0f, 0.0f, 3.0f, 1, 0xFF27ECFF }, // 5
	{ 3, 0, 1, 0, 0, 1, 100.0f, 100.0f, 120.0f, 40.0f, 3.0f, 1, 0xFFFFAD29 }, // 6
	{ 0, 1, 0, 0, 1, -1, 180.0f, 100.0f, 40.0f, 40.0f, 3.0f, 1, 0xFF4D00FF }, // 7
	{ 2, 1, 0, 0, 0, -1, 300.0f, 60.0f, 32.0f, 32.0f, 3.0f, 1, 0xFFFFFFFF }, // 8
	{ 1, 1, 0, 0, 0, 2, 10.0f, 8.0f, 0.0f, 0.0f, 3.0f, 1, 0xFFFFFFFF }, // 9
	{ 1, 1, 1, 0, 0, 3, 20.0f, 110.0f, 0.0f, 0.0f, 3.0f, 1, 0xFFC7C3C2 }, // 10
};
static Obj objs[6];
static int vars[NUM_VARS] = { 0 };
static int cur_scene = START_SCENE, next_scene = -1, scene_frames = 0, quit = 0;
static const u32 scene_bg[NUM_SCENES][2] = {
	{ 0xFF532B1D, 0xFF222222 },
	{ 0xFF518700, 0xFF222222 },
};
static const float screen_w[2] = { 400.0f, 320.0f };
static const float screen_h[2] = { 240.0f, 240.0f };

static void format_text(int tmpl, char* out, size_t n) {
	switch (tmpl) {
	case 0: snprintf(out, n, "MI PRIMER JUEGO"); break;
	case 1: snprintf(out, n, "Jugar"); break;
	case 2: snprintf(out, n, "Puntos: %d", vars[0]); break;
	case 3: snprintf(out, n, "D-Pad: mover   START: men\303\272"); break;
	default: out[0] = 0; break;
	}
}

static int hit(int a, int b) {
	const Obj *p = &objs[a], *q = &objs[b];
	return p->visible && q->visible && p->screen == q->screen &&
		p->x < q->x + q->w && q->x < p->x + p->w && p->y < q->y + q->h && q->y < p->y + p->h;
}

static int touch_in(int i, int touched, int tx, int ty) {
	const Obj* o = &objs[i];
	return touched && o->visible && o->screen == 1 && tx >= o->x && tx < o->x + o->w && ty >= o->y && ty < o->y + o->h;
}

static void random_pos(int i) {
	Obj* o = &objs[i];
	float mw = screen_w[o->screen] - o->w, mh = screen_h[o->screen] - o->h;
	o->x = (float)(rand() % (int)(mw > 1 ? mw : 1));
	o->y = (float)(rand() % (int)(mh > 1 ? mh : 1));
}

static void enter_scene(int s) {
	cur_scene = s;
	scene_frames = 0;
	for (int i = 0; i < NUM_OBJS; i++) if (init_objs[i].scene == s) objs[i] = init_objs[i];
}

/* ---------- Audio (ndsp, WAV PCM16 en romfs:/sounds) ---------- */
#if NUM_SOUNDS > 0
typedef struct { s16* data; u32 samples; u32 rate; int channels; int ok; } Sound;
static Sound sounds[NUM_SOUNDS];
static ndspWaveBuf wave_bufs[NUM_SOUNDS];
static int audio_ok = 0;
static const char* sound_files[NUM_SOUNDS] = {
	"romfs:/sounds/moneda-2.wav",
	"romfs:/sounds/your-last-chance-as-rea-14.wav",
};

static void load_sounds(void) {
	audio_ok = R_SUCCEEDED(ndspInit());
	if (!audio_ok) return;
	ndspSetOutputMode(NDSP_OUTPUT_STEREO);
	for (int i = 0; i < NUM_SOUNDS; i++) {
		FILE* f = fopen(sound_files[i], "rb");
		if (!f) continue;
		u8 h[44];
		if (fread(h, 1, 44, f) != 44 || memcmp(h, "RIFF", 4) || memcmp(h + 36, "data", 4)) { fclose(f); continue; }
		u32 size = h[40] | (h[41] << 8) | (h[42] << 16) | ((u32)h[43] << 24);
		sounds[i].channels = h[22];
		sounds[i].rate = h[24] | (h[25] << 8) | (h[26] << 16) | ((u32)h[27] << 24);
		sounds[i].data = (s16*)linearAlloc(size);
		if (sounds[i].data && fread(sounds[i].data, 1, size, f) == size) {
			DSP_FlushDataCache(sounds[i].data, size);
			sounds[i].samples = size / (2 * sounds[i].channels);
			sounds[i].ok = 1;
		}
		fclose(f);
	}
}

static void play_sound(int i) {
	if (!audio_ok || i < 0 || i >= NUM_SOUNDS || !sounds[i].ok) return;
	float mix[12] = { 0 };
	mix[0] = mix[1] = 1.0f;
	ndspChnReset(i);
	ndspChnSetInterp(i, NDSP_INTERP_LINEAR);
	ndspChnSetRate(i, (float)sounds[i].rate);
	ndspChnSetFormat(i, sounds[i].channels == 1 ? NDSP_FORMAT_MONO_PCM16 : NDSP_FORMAT_STEREO_PCM16);
	ndspChnSetMix(i, mix);
	memset(&wave_bufs[i], 0, sizeof(ndspWaveBuf));
	wave_bufs[i].data_vaddr = sounds[i].data;
	wave_bufs[i].nsamples = sounds[i].samples;
	ndspChnWaveBufAdd(i, &wave_bufs[i]);
}

static void free_sounds(void) {
	if (!audio_ok) return;
	for (int i = 0; i < NUM_SOUNDS; i++) if (sounds[i].data) linearFree(sounds[i].data);
	ndspExit();
}
#else
static void load_sounds(void) {}
static void play_sound(int i) { (void)i; }
static void free_sounds(void) {}
#endif

/* ---------- Lógica ---------- */
static void update(u32 down, u32 held, int touched, int tx, int ty) {
	for (int i = 0; i < NUM_OBJS; i++) {
		Obj* o = &objs[i];
		if (o->scene != cur_scene || !o->controls || !o->visible) continue;
		if (held & KEY_DLEFT)  o->x -= o->speed;
		if (held & KEY_DRIGHT) o->x += o->speed;
		if (held & KEY_DUP)    o->y -= o->speed;
		if (held & KEY_DDOWN)  o->y += o->speed;
		if (o->x < 0) o->x = 0;
		if (o->y < 0) o->y = 0;
		if (o->x > screen_w[o->screen] - o->w) o->x = screen_w[o->screen] - o->w;
		if (o->y > screen_h[o->screen] - o->h) o->y = screen_h[o->screen] - o->h;
	}
	(void)down; (void)held; (void)touched; (void)tx; (void)ty;
	switch (cur_scene) {
	case 0: // Men_
		if (touch_in(1, touched, tx, ty)) {
			vars[0] = 0;
			next_scene = 1;
		}
		break;
	case 1: // Juego
		if (hit(2, 3)) {
			vars[0] += 1;
			play_sound(0);
			random_pos(3);
			play_sound(1);
		}
		if ((down & KEY_START)) {
			next_scene = 0;
		}
		break;
	default: break;
	}
	scene_frames++;
}

/* ---------- Dibujo ---------- */
static C2D_SpriteSheet sheet;
static C2D_TextBuf text_buf;

static void draw_text(const char* s, float x, float y, u32 color) {
	C2D_Text t;
	C2D_TextParse(&t, text_buf, s);
	C2D_TextOptimize(&t);
	C2D_DrawText(&t, C2D_WithColor, x, y, 0.0f, 0.55f, 0.55f, color);
}

static void draw_screen(int screen) {
	char buf[96];
	for (int i = 0; i < NUM_OBJS; i++) {
		const Obj* o = &objs[i];
		if (o->scene != cur_scene || !o->visible || o->screen != screen) continue;
		switch (o->type) {
		case T_RECT: C2D_DrawRectSolid(o->x, o->y, 0.0f, o->w, o->h, o->color); break;
		case T_SPRITE:
			{ C2D_Image img = C2D_SpriteSheetGetImage(sheet, o->image);
			  C2D_DrawImageAt(img, o->x, o->y, 0.0f, NULL, o->w / img.subtex->width, o->h / img.subtex->height); }
			break;
		case T_TEXT: format_text(o->tmpl, buf, sizeof buf); draw_text(buf, o->x, o->y, o->color); break;
		case T_BUTTON:
			C2D_DrawRectSolid(o->x, o->y, 0.0f, o->w, o->h, o->color);
			format_text(o->tmpl, buf, sizeof buf);
			draw_text(buf, o->x + 6, o->y + o->h / 2 - 8, 0xFF000000);
			break;
		}
	}
}

int main(int argc, char* argv[]) {
	(void)argc; (void)argv;
	gfxInitDefault();
	romfsInit();
	C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
	C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
	C2D_Prepare();
	C3D_RenderTarget* top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
	C3D_RenderTarget* bottom = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
	text_buf = C2D_TextBufNew(8192);
	sheet = C2D_SpriteSheetLoad("romfs:/gfx/sprites.t3x");
	if (!sheet) svcBreak(USERBREAK_PANIC);
	load_sounds();
	srand((unsigned)svcGetSystemTick());
	enter_scene(START_SCENE);

	while (aptMainLoop() && !quit) {
		hidScanInput();
		u32 down = hidKeysDown(), held = hidKeysHeld();
		touchPosition tp;
		hidTouchRead(&tp);
		update(down, held, (down & KEY_TOUCH) != 0, tp.px, tp.py);
		if (next_scene >= 0) { enter_scene(next_scene); next_scene = -1; }

		C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
		C2D_TextBufClear(text_buf);
		C2D_TargetClear(top, scene_bg[cur_scene][0]);
		C2D_SceneBegin(top);
		draw_screen(0);
		C2D_TargetClear(bottom, scene_bg[cur_scene][1]);
		C2D_SceneBegin(bottom);
		draw_screen(1);
		C3D_FrameEnd(0);
	}

	free_sounds();
	C2D_SpriteSheetFree(sheet);
	C2D_TextBufDelete(text_buf);
	C2D_Fini();
	C3D_Fini();
	romfsExit();
	gfxExit();
	return 0;
}
